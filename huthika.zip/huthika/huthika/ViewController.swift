//
//  ViewController.swift
//  huthika
//
//  Created by Pranathi P on 11/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var heightOL: UITextField!
    var BMI = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calcBTN(_ sender: Any) {
        var weight = Double(weightOL.text!)
        var height = Double(heightOL.text!)
        
        var bodymassindex = (weight!*703)/(height!*height!)
        
        BMI = Double(round(100 * bodymassindex)/100)
        
        
        //
        //        if(BMI < 18.45){
        //            imageName = "underweight"
        //        }else if (BMI > 18.45 && BMI < 60.00){
        //            imageName = "normal"
        //        }else if (BMI >= 60.00 && BMI < 100.00){
        //            imageName = "overweight"
        //        }else  {
        //            imageName = "obssed"
        //
        //        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as!
            ResultViewController
            destination.weight=weightOL.text!
            destination.height = heightOL.text!
            destination.BMI = BMI
            //  destination.imageName = imageName
            
        }
        
    }}

