import UIKit

var greeting = "Hello, playground"

print("June 2014 was the first version of the Swift programming language introduced.")
print("----------------------")

let pi = 3.14
let radius = 7.5
var circumferance = 2 * pi * radius
print("\(circumferance)")
print("----------------------")
var Fahrenheit = 98.8
var Celsius = ((Fahrenheit - 32) * 5/9)
let newvalue = String(format:"%.2f", Celsius)
print("Fahrenheit: \(Fahrenheit) F")
print("Celsius:    \(newvalue) C")
print("----------------------")
print("Hello everyone, my name is Pranathi Patlolla.", terminator : " ")
print("I'm currenty pursuing my masters in computer science in Northwest missouri state university.")
print("I am from India")
print("----------------------")
print("""
Swift is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.
Writing Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features developers love.
Swift code is safe by design and produces software that runs lightning-fast.
""")
print("----------------------")
var number = 123457
var count = String (number).count
print("The number \(number) has \(count) digits")
print("----------------------")
var name = "Welcome to iOS Class"
var output = ""
for character in name{
    if character != " "{
        if !output.isEmpty{
            output += ","
        }
        output+=String(character)
    }
}
print(output)
print("----------------------")

