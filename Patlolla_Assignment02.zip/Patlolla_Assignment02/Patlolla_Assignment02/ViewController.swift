//
//  ViewController.swift
//  Patlolla_Assignment02
//
//  Created by Pranathi P on 9/9/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        
        
        
        if let name = nameOutlet.text,
        
        let billA = billAmountOutlet.text,
        
        let tip = tipPercentageOutlet.text,
        
        
        
        
        
        
        
        
          let billValue = Double(billA),let tipValue = Double(tip)
        {
            let tipCalc = (billValue * tipValue) / 100.0
            let totalAmount = billValue+tipCalc
            
            
            
            nameLabel.text = "Name: \(name)"
            billAmountLabel.text = "Bill Amount: $\(billA)"
            tipAmountLabel.text = "Tip Amount: $\(tipCalc)"
            totalAmountLabel.text = "Total Amount: $\(totalAmount)"
            
        }
        
        
    }

    
    @IBAction func ResetBTN(_ sender: UIButton) {
        
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
        
        
    }
}

