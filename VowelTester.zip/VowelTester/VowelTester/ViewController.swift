//
//  ViewController.swift
//  VowelTester
//
//  Created by Patlolla,Pranathi on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BTNclick(_ sender: UIButton) {
        
        //Read the input text and assign it to a variable.
        
        var input=inputOL.text!
        
        input.lowercased()
        
        //Check if the variable having vowels or or not.
        
        if(input.contains("A") || input.contains("E") || input.contains("I") || input.contains("O") || input.contains("U")){
            outputOL.text = "The \(input) has vowels."
        }
        else{
            outputOL.text="The \(input) has no vowels."
        }
        
        //If text has a e i o u , print "Original text" has vowels.
        //else, the "original text" has no vowels.
        
        
    }
    
}

