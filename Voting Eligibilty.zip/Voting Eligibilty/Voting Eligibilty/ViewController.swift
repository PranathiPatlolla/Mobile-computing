//
//  ViewController.swift
//  Voting Eligibilty
//
//  Created by Patlolla,Pranathi on 9/5/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var InputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckBTN(_ sender: UIButton) {
        var input = Int(InputOL.text!)
        if(input!>=18)
        {
            outputOL.text = "Eligible"
            
            
        }
        else{
            outputOL.text = "Not Eligible"
        }
        
    }
    
}

