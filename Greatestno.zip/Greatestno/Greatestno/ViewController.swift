//
//  ViewController.swift
//  Greatestno
//
//  Created by Patlolla,Pranathi on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputFN: UITextField!
    
    
    @IBOutlet weak var inputSN: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BTNclicked(_ sender: UIButton) {
        //Read inputs and connect it to variable.
        var input1 = Int(inputFN.text!)
        var input2 = Int(inputSN.text!)
        //Check if the greatest number in the numbers
        
        if(input1!>input2!){
            outputOL.text="First number is greatest"
        }
        else if(input2!>input1!){
            outputOL.text="Secound number is greatest"
        }
        else{
            outputOL.text="NUmbers are equal"
        }
        
    }
    
}

