//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Patlolla,Pranathi on 9/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var crsNumber: UILabel!
    
    @IBOutlet weak var crsName: UILabel!
    
    @IBOutlet weak var semOffered: UILabel!
    
    @IBOutlet weak var prevBtnOL: UIButton!
    
    
    @IBOutlet weak var nxtBtnOL: UIButton!
    
    var courses = [["img01","44542","Network Security","Fall 2023"],
                   ["img02","44643","IOS","Fall 2023"],
                   ["img03","44555","Data Streming","Summer 2023"]]
    var imgeNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //previous should be disabled
        prevBtnOL.isEnabled = false
        
        //display the first course details
        updateDisplay(imgeNumber)
        
        
        
        
    }

    @IBAction func prevBtnClicked(_ sender: UIButton) {
        //next button should be enabled
        nxtBtnOL.isEnabled = true
        //decrement the imageNumber
        imgeNumber -= 1
        //update the display using updateDisplay()
        updateDisplay(imgeNumber)
        //if we reached the beging of the array prev should be disabled
        if(imgeNumber == 0){
            prevBtnOL.isEnabled = false
        }
    }
    
    @IBAction func nextBtnClicked(_ sender: UIButton) {
        
        //preivous Btn should be enabled
        prevBtnOL.isEnabled = true
        
        //next course in an array should be displayed
        imgeNumber += 1
        updateDisplay(imgeNumber)
        //when we reach end of the array the next btn should be disabled
        if(imgeNumber == courses.count-1){
            nxtBtnOL.isEnabled = false
        }
        
        
    }
    func updateDisplay(_ imgeNumber:Int){
        crsNumber.text = courses[imgeNumber][1]
        crsNumber.text = courses[imgeNumber][2]
        semOffered.text = courses[imgeNumber][3]
        imageDisplay.image = UIImage(named: courses[imgeNumber][0])
    }
}

