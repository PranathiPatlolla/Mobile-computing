//
//  ViewController.swift
//  BMICalculator
//
//  Created by Patlolla,Pranathi on 11/2/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var heightOL: UITextField!
    
    
    var afterBMI = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcBtn(_ sender: Any) {
        
        var Weight = Double(weightOL.text!)
        var Height = Double(heightOL.text!)
        
        afterBMI = (Weight!*703)/(Height!*703)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transaction = segue.identifier
        
        if transaction == "resultSegue"{
            
            let destination = segue.destination as!
            BMIViewController
            
            destination.Height = heightOL.text!
            destination.Weight = weightOL.text!
            
            destination.afterBMI = afterBMI
            
        }
    }
    
}

