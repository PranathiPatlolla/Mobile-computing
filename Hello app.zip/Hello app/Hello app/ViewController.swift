//
//  ViewController.swift
//  Hello app
//
//  Created by Patlolla,Pranathi on 8/29/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOl: UITextField!
    @IBOutlet weak var inputLN: UITextField!
    
    
    @IBOutlet weak var LabelBtn: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Submitbtn(_ sender: Any) {
        
        var firstname = inputOl.text!
        var lastname = inputLN.text!
        
        LabelBtn.text="Hello, \(firstname) \(lastname)😍"
        
        
        
    }
    
}

