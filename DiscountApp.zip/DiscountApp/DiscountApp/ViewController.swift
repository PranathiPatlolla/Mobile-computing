//
//  ViewController.swift
//  DiscountApp
//
//  Created by Patlolla,Pranathi on 10/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var AmountOL: UITextField!
    
    
    @IBOutlet weak var DiscountOL: UITextField!
    
   var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calcBtn(_ sender: UIButton) {
        
        //read the amount from amountOl
       var amount = Double(AmountOL.text!)
        var discount = Double(DiscountOL.text!)
        
    priceAfterDiscount = amount! - (amount!*discount!/100)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       var transition = segue.identifier
        
        if transition == "resultSegue"{
            
            let destination = segue.destination as!
            ResultViewContollerViewController
            
            destination.amount = AmountOL.text!
            destination.discount = DiscountOL.text!
            
            destination.priceAfterDiscount = priceAfterDiscount
        }
        
    }
}


