//
//  ResultViewContollerViewController.swift
//  DiscountApp
//
//  Created by Patlolla,Pranathi on 10/31/23.
//

import UIKit

class ResultViewContollerViewController: UIViewController {
    
    
    @IBOutlet weak var displayAmountOL: UILabel!
    
    @IBOutlet weak var displayDiscrateOL: UILabel!
    
    
    @IBOutlet weak var displayPriceAfterDiscOL: UILabel!
    
    var amount = ""
    var discount = ""
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        displayAmountOL.text! += amount
        displayDiscrateOL.text! += discount
        displayPriceAfterDiscOL.text! += String(priceAfterDiscount)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
