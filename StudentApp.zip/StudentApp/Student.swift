//
//  Student.swift
//  StudentApp
//
//  Created by Patlolla,Pranathi on 11/7/23.
//

import Foundation
