//
//  ViewController.swift
//  Patlolla_CalculatorApp
//
//  Created by Pranathi P on 9/19/23.
//

import UIKit

class ViewController: UIViewController {
    var cval: Double = 0
        var pVal: Double = 0
        var currentOp: String = ""
        var inputNumber = false
        var minusSign = false


    @IBOutlet weak var resultOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ACBtn(_ sender: UIButton) {
        cval = 0
        pVal = 0
        currentOp = ""
        resultOutlet.text = "0"
        inputNumber = false
        minusSign = false
    }
    
    @IBAction func CBtn(_ sender: UIButton) {
        resultOutlet.text = "0"
        minusSign = false
    }
    
    
    @IBAction func ASBtn(_ sender: UIButton) {
        if inputNumber {
        minusSign = !minusSign
        if minusSign {
        resultOutlet.text = "-" + resultOutlet.text!
        } else {
        resultOutlet.text?.removeFirst()
        }
        }
    }
    
    @IBAction func DBtn(_ sender: UIButton) {
        controlOperator("÷")
    }
    
    @IBAction func Btn7(_ sender: UIButton) {
        forDigit(7)
    }
    
    @IBAction func Btn8(_ sender: UIButton) {
        forDigit(8)
    }
    
    @IBAction func Btn9(_ sender: UIButton) {
        forDigit(9)
    }
    
    @IBAction func MulBtn(_ sender: UIButton) {
        controlOperator("x")
    }
    
    @IBAction func Btn4(_ sender: UIButton) {
        forDigit(4)
    }
    
    @IBAction func Btn5(_ sender: UIButton) {
        forDigit(5)
    }
    
    @IBAction func Btn6(_ sender: Any) {
        forDigit(6)
    }
    
    @IBAction func SubBtn(_ sender: UIButton) {
        controlOperator("-")
    }
    
    @IBAction func Btn1(_ sender: UIButton) {
        forDigit(1)
    }
    
    @IBAction func Btn2(_ sender: UIButton) {
        forDigit(2)
    }
    
    @IBAction func Btn3(_ sender: UIButton) {
        forDigit(3)
    }
    
    @IBAction func AddBtn(_ sender: UIButton) {
        controlOperator("+")
    }
    
    @IBAction func Btn0(_ sender: UIButton) {
        forDigit(0)
    }
    
    @IBAction func BtnDot(_ sender: UIButton) {
        if inputNumber && !resultOutlet.text!.contains(".") {
                   resultOutlet.text! += "."
               } else if !inputNumber {
                   resultOutlet.text = "0."
                   inputNumber = true
               }
    }
    
    @IBAction func ModBtn(_ sender: UIButton) {
        controlOperator("%")
    }
    
    @IBAction func EqualBtn(_ sender: UIButton) {
        if inputNumber {
        let secondOperand = Double(resultOutlet.text!) ?? 0
        switch currentOp {
        case "+":
            cval = cval + secondOperand
        case "-":
            cval = cval - secondOperand
        case "x":
            cval = cval * secondOperand
        case "÷":
        if secondOperand != 0 {
            cval = cval / secondOperand
        } else {
            resultOutlet.text = "Not a number"
            return
        }
        case "%":
            cval = cval.truncatingRemainder(dividingBy: secondOperand)
        default:
        break
        }
        resultOutlet.text = result(cval)
            inputNumber = false
            minusSign = false
        }
    }
    func forDigit(_ digit: Int) {
            if inputNumber {
                if resultOutlet.text == "0" || resultOutlet.text == "-0" {
                    if digit >= 0 && digit <= 9 {
                        resultOutlet.text = minusSign ? "-" + "\(digit)" : "\(digit)"
                    }
                } else {
                    resultOutlet.text! += "\(digit)"
                }
            } else {
                resultOutlet.text = minusSign ? "-" + "\(digit)" : "\(digit)"
                inputNumber = true
            }
        }
    func controlOperator(_ operatorSymbol: String) {
            if let currentText = resultOutlet.text,
                let cvalue = Double(currentText) {
                cval = cvalue
            }
            
            currentOp = operatorSymbol
            clearDisplayLabel()
        }
        
        func clearDisplayLabel() {
            resultOutlet.text = ""
        }
        
        func result(_ number: Double) -> String {
            let num = NumberFormatter()
            num.minimumFractionDigits = 0
            num.maximumFractionDigits = 5
            
            return num.string(from: NSNumber(value: number)) ?? ""
        }
}

